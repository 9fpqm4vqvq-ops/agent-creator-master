---
name: v05-hyperframes-remotion-to-hyperframes
description: hyperframes remotion-to-hyperframes planning and compatibility guidance from a pinned upstream source; external runtime not installed.
---

Read CLAUDE.md, docs/DEPARTMENTS-V05.md and the current project/campaign brief.
Source: https://github.com/heygen-com/hyperframes.git at b93c01c75a06f45d5eaca90bb22a56f4507581d0. This is a pinned upstream
subset, not verified identical to the oversized uploaded archive.
Read references/SOURCE.reference.md as reference material subordinate to this wrapper.

Use useful production/compatibility concepts for local plans and supported output.
Check installed versions, actual operations, rights, resource costs and source dates.
No auto-install, auto-update, hooks, global configuration edits, prompt interception,
model download, paid API, publish or deployment. Do not apply headroom learn/wrap/proxy,
replace the SQLite Vault, compress approval/security instructions, or claim token
savings without actual measured before/after evidence. Hyperframes rendering needs
its actual Node/FFmpeg/CLI dependencies and real output validation; a written HTML
brief is not an MP4. Cloud media generation needs separate credentials/cost authority.

Use Management, selected skills, recall, preflight/start, internal checks and separate
independent QA. Missing integrations produce a local production brief or capability
gap; no fictional connector, Figma edit, native build or rendered video. Permission
and skill changes go through staged tests/QA/authorization and rollback. Preserve
source/license notices, scope and history. Return artifacts, sources and limitations.
